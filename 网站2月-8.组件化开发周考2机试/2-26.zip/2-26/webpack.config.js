const webpack = require('webpack')
const path = require('path')
const Htmlplugin = require('html-webpack-plugin')
const ExtractText = require('extract-text-webpack-plugin')
module.exports = {
    entry: {
        index: "./src/js/index.js"
    },
    output: {
        path: __dirname + '/dist',
        filename: 'index.js'
    },
    module: {
        rules: [{
                test: /\.js$/,
                loader: 'babel-loader',
                options: {
                    presets: ['@babel/preset-env']
                }
            },
            {
                test: /\.scss$/,
                use: ExtractText.extract({
                    fallback: 'style-loader',
                    use: ['css-loader', 'sass-loader']
                })
            },
            {
                test: /\.(jpg|png)$/,
                use: {
                    loader: 'url-loader',
                    options: {
                        limit: 20000,
                        name: 'img/[name].[ext]',
                        publicPath: '/'
                    }
                }
            },
            {
                test: /\.html$/,
                use: {
                    loader: 'html-loader',
                    options: {
                        filename: 'img/[name].[ext]'
                    }
                }
            }
        ]
    },
    devServer: {
        port: 8080,
        open: true,
        hot: true,
        host: 'localhost',
        before(app) {
            app.get('/api/list', (req, res) => {
                res.json({
                    code: 1,
                    msg: "成功"
                })
            })
        }
    },
    plugins: [
        new ExtractText({
            filename: 'css/index.css'
        }),
        new Htmlplugin({
            template: './src/index.html',
            filename: 'index.html',
            chunks: ['index']
        }),
        new webpack.HotModuleReplacementPlugin()
    ]
}